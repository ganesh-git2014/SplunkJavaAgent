1.0
---
Support for Java 7/8 , specifically stackmap frames.
Can optionally pass the properties file in as an argument , rather than having to bundle it into the agent jar
Example : -javaagent:splunkagent.jar=/Users/foo/splunkagent.properties

0.5
---
Initial beta release
